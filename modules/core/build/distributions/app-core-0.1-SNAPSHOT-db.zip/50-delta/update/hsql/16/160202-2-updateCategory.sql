alter table DELTA_CATEGORY add column RELIAZIATION_PRICE decimal(19, 2) ;
