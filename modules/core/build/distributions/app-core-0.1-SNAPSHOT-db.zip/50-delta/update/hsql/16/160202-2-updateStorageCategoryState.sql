alter table DELTA_STORAGE_CATEGORY_STATE alter column STORAGE_ID set not null ;
