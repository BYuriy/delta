alter table DELTA_CATEGORY drop constraint FK_DELTA_CATEGORY_CATEGROY_ID;
drop table DELTA_SUB_GROUPS cascade ;
