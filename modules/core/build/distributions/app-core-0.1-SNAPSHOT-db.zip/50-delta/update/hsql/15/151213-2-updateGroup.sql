alter table DELTA_GROUP add column PARENT_ID varchar(36) ;
