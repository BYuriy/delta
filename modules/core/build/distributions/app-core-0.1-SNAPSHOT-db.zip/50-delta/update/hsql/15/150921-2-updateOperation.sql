alter table DELTA_OPERATION add column STORAGE_DESTINATION_ID varchar(36) ;
