drop table DELTA_MATERIAL cascade ;
