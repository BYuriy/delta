drop table DELTA_STORAGE_MATERIAL_STATE cascade ;
