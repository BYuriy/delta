drop table DELTA_MATERIAL_CATEGORY cascade ;
