alter table DELTA_MATERIAL add column CATEGROY_ID varchar(36) ;
