alter table DELTA_OPERATION alter column SUMMARY_PRICE set null ;
