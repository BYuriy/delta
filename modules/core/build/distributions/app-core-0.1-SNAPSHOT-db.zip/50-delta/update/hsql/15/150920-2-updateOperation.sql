alter table DELTA_OPERATION alter column AVERAGE_PRICE set null ;
