drop table DELTA_SUB_GROUP cascade ;
