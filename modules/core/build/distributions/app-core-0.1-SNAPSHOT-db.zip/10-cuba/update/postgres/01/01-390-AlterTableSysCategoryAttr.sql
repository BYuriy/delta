-- $Id: 01-390-AlterTableSysCategoryAttr.sql 6252 2011-10-18 05:28:41Z novikov $
-- Description:
ALTER TABLE SYS_CATEGORY_ATTR ALTER COLUMN DEFAULT_DATE TYPE timestamp;