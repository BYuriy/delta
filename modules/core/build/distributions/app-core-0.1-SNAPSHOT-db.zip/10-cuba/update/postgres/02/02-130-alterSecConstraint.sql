--$Id: 02-130-alterSecConstraint.sql 13792 2013-10-17 11:10:31Z artamonov $

alter table SEC_CONSTRAINT alter WHERE_CLAUSE type varchar(1000);