-- $Id: 01-040-renameUserPosition.sql 5224 2011-07-05 05:34:27Z krivopustov $
-- Description: sec_user.position field

alter table sec_user rename column position to position_
^
