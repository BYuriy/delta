-- $Id: 01-380-AlterTypeColumnUrlInScreenHistory.sql 6207 2011-10-14 12:23:49Z novikov $
-- Description:
ALTER TABLE SEC_SCREEN_HISTORY ALTER column URL type TEXT;