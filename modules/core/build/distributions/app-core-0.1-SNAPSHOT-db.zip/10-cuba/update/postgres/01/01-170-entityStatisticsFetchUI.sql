-- $Id: 01-170-entityStatisticsFetchUI.sql 5224 2011-07-05 05:34:27Z krivopustov $
-- Description: add SYS_ENTITY_STATISTICS.FETCH_UI column

alter table SYS_ENTITY_STATISTICS add FETCH_UI integer^
