-- $Id: 01-400-AlterTableSysAttrValue.sql 6254 2011-10-18 06:47:49Z novikov $
-- Description:
ALTER TABLE SYS_ATTR_VALUE ALTER COLUMN DATE_VALUE TYPE timestamp;