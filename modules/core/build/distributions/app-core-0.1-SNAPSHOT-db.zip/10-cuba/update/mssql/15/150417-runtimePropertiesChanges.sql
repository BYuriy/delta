-- $Id: 150417-runtimePropertiesChanges.sql 21646 2015-06-09 11:00:25Z degtyarjov $
alter table SYS_ATTR_VALUE add CODE varchar(100)^
alter table SYS_CATEGORY_ATTR add TARGET_SCREENS varchar(4000)^

